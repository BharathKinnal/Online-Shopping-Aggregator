<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ShopsMart</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.6.2/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
  </head>
  
  <body>
    <section class="hero is-primary">
      <div class="hero-body">
        <div class="container">
          <h1 class="title">ShopsMart</h1>
          <h2 class="subtitle">
            Search for products.
          </h2>
        </div>
      </div>
    </section>
    
    <?php
      $keyword= $_REQUEST['keyword'];
    ?>

    <div class=" column container is-three-quarters ">
      <form action="<?php 
                      if($keyword==='')
                        {echo htmlspecialchars('bharath.php');}
                      else
                        {echo htmlspecialchars('products.php');}
                    ?>" method="post">
        <div class="columns">
          <div class="column is-four-fifths">
            <div class="field">
              <div class=" level control has-icons-left">
                <span class="icon is-large is-left" style="margin-top:10px;margin-left:10px;">
                  <i class="fas fa-2x fa-search"></i>
                </span>
                <input class=" input is-large is-info" type="text" placeholder="Search for a product across the web..." value="<?php echo htmlspecialchars($keyword);?>" id='keyword' name='keyword'>
              </div>
            </div>
          </div>
          <div class="column container">
            <input style="height:50px" class="button is-primary" type="submit" value="Submit"/>
          </div>
        </div>
      </form>
    </div>
    
    <section class="columns">
      <div class="columns is-multiline column is-one-third is-gapless" style="height:200px">
      <p class="subtitle">
        <br>
          Search from these websites :
        <br>
      </p>
        <div class="column is-half">
          <a href="https://www.flipkart.com">
            <figure class="image is-2by1">
              <img src="img/flipkart.png">
            </figure>
          </a>
        </div>

        <div class="column is-half">
          <a href="https://www.amazon.in">
            <figure class="image is-2by1">
              <img src="img/amazon.png">
            </figure>
          </a>
        </div>
        
      </div>
  
      <section style=" overflow-y: scroll;height:400px;" class="column is-two-thirds">
        <?php
          require 'simple_html_dom.php';

          $title=array();
          $href=array();
          $site=array();
          $price=array();
          $image=array();
          
          
          $base = 'https://www.amazon.in/s/ref=nb_sb_noss_2/257-0758379-5743540?url=search-alias%3Daps&field-keywords='.$keyword;

          $curl = curl_init();
          curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
          curl_setopt($curl, CURLOPT_HEADER, false);
          curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
          curl_setopt($curl, CURLOPT_URL, $base);
          curl_setopt($curl, CURLOPT_REFERER, $base);
          curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
          $str = curl_exec($curl);
          curl_close($curl);

          // Create a DOM object
          $html_base = new simple_html_dom();
          // Load HTML from a string
          $html_base->load($str);
    

          //$html=file_get_html('https://www.amazon.in/s/ref=nb_sb_noss_2/257-0758379-5743540?url=search-alias%3Dap&field-keywords=laptop');

          //if(is_null($html))
          //echo '0';
          $j=0;
          foreach($html_base->find('li') as $item)
          {
            //echo 'a<br/>';
          $i=0;
          foreach($item->find('span[class="a-size-base a-color-price s-price a-text-bold"]') as $element)
          {
            //echo $element->innertext . '<br>';
            //$element=$item->find('span[class="a-size-base a-color-price s-price a-text-bold"]');
            $p=$element->innertext;
            
            //preg_replace('/[^0-9]/', '', $p);
            //preg_match_all('!\d+!', $p, $p);
            $int = (int) filter_var($p, FILTER_SANITIZE_NUMBER_INT);
            //echo $int."<br/>";
            if(is_numeric($int))
            {
              array_push($price, $int);
              $i++;
              //echo $price[$j];
              $j++;
            }
            else
              echo 'a';
          }
          //echo $i.'<br/>';
          if($i==1)
          {
          foreach($item->find('h2') as $element)
          {
            //echo $element->innertext . '<br>';
            //$element=$item->find('h2');
            //$title[]=$element->plaintext;
            //$href[]=$element->parent()->href;
            //$site[]="https://www.amazon.in";
            array_push($title, $element->plaintext);
            array_push($href, $element->parent()->href);
            array_push($site, "https://www.amazon.in");
            
          }

          

          foreach($item->find('img[class="s-access-image cfMarker"]') as $element)
          {
            //$element=$item->find('img[class="s-access-image cfMarker"]');
            //$image[]=$element->src;
            array_push($image, $element->src);
           
        
          }
          }  
          
          }
          //echo $title[0];
          //echo $i;
          //print_r($x);

          for ($i=0;$i<count($price);$i++)
          {
            if(strpos($title[$i],"[Sponsored]")===0)
            {
              array_splice($title,$i,1);
              array_splice($image,$i,1);
              array_splice($site,$i,1);
              array_splice($price,$i,1);
              array_splice($href,$i,1);
              $i--;
              //echo $i.'<br/>';
            }
          }
          
          $base = 'https://www.flipkart.com/search?q='.$keyword.'&otracker=start&as-show=on&as=off';

          $curl = curl_init();
          curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
          curl_setopt($curl, CURLOPT_HEADER, false);
          curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
          curl_setopt($curl, CURLOPT_URL, $base);
          curl_setopt($curl, CURLOPT_REFERER, $base);
          curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
          $str = curl_exec($curl);
          curl_close($curl);

          // Create a DOM object
          $html_base = new simple_html_dom();
          // Load HTML from a string
          $html_base->load($str);
    
          foreach($html_base->find('a[class="_1UoZlX"]') as $item)
          {
            //echo 'a<br/>';
          $i=0;
          foreach($item->find('div[class="_1vC4OE _2rQ-NK"]') as $element)
          {
            $p=$element->innertext;
            //$p = substr($p, 1);
            $k = mb_convert_encoding($p, 'UCS-2LE', 'UTF-8');
            //$k1 = ord(substr($k, 0, 1))
            $k = substr($k, 18);
            preg_replace("/[^0-9]/", '', $k);
            //preg_match_all('!\d+!', $k, $k);
            $int = (int) filter_var($k, FILTER_SANITIZE_NUMBER_INT);
            
            //echo $int . '<br/><br/>';
            if(is_numeric($int))
            {
              array_push($price, $int);
              $i++;
              //echo $price[$j];
              $j++;
            }
            else
              echo 'a';
          }
            
          
          //echo $i.'<br/>';
          if($i==1)
          {
          foreach($item->find("img") as $element)
          {
            //$a="https://www.flipkart.com";
            //$a=$a.$element->href;
          
            $imgclass=$element->parent()->class;
            $src=$element->src;
            $ref=$element->parent()->parent()->parent()->parent()->parent()->href;
            if($imgclass=="_3BTv9X"){
              if($element->src=='')
                array_push($image,'img/question.png');
              else
                array_push($image,$element->src);
              array_push($href,'https://www.flipkart.com'.$ref);
              array_push($site,'https://www.flipkart.com');
              

              array_push($title, $element->alt);
            }
          } 
          }  
          
          }          //echo $price[0];
          //echo $i;
          //print_r($x);

          /*for ($i=0;$i<count($price);$i++)
          {
            if(strpos($title[$i],"[Sponsored]")===0)
            {
              array_splice($title,$i,1);
              array_splice($image,$i,1);
              array_splice($site,$i,1);
              array_splice($price,$i,1);
              array_splice($href,$i,1);
              $i--;
              //echo $i.'<br/>';
            }
          }
          */
          
          function swap_items(&$i,&$j)
          {
            $q=$i;
            $i=$j;
            $j=$q;
          }

          for ($i=0;$i<count($price);$i++)
          {
            for($j=0;$j<$i;$j++)
            {
              if($price[$j]>$price[$i])
              {
                swap_items($price[$i],$price[$j]);
                swap_items($title[$i],$title[$j]);
                swap_items($site[$i],$site[$j]);
                swap_items($href[$i],$href[$j]);
                swap_items($image[$i],$image[$j]);
                
                //echo $i.'<br/>';
              }
            }
          }
          
          
          //echo count($price).'<br/>';
          for ($i=0;$i<count($price);$i++):   
          
        ?>
        <a class="card" style="height:150px;" href="<?php echo htmlspecialchars($href[$i]);?>">
          <div class="card-content">
            <div class="media">
              <section class="columns">
                
                <div class="media-left column is-one-fifth" href="<?php echo htmlspecialchars($href[$i]);?>">
                  <figure class="image is-70x70">
                    <img src= "<?php echo htmlspecialchars($image[$i]); ?>" alt="Image not found!">
                  </figure>
                </div>
                <div class="media-content column is-four-fifths">
                  <section>
                    <div class="subtitle is-5" style="height:100px"><?php echo $title[$i];?></div>
                  </section>
                  <section class="columns">
                    <div class="subtitle is-6 column is-one-third has-text-weight-semibold">
                        Rs.<?php echo $price[$i];?>    
                    </div>
                    <div class="subtitle is-6 column">
                        <?php echo $site[$i];?>    
                    </div>
                  </section>
                </div>
              </section>
            </div>
          </div>
        </a> 
        
                
        <?php
          endfor;
          if(count($price)<=0)
            echo "<br/><br/><br/><br/><div class='hero is-warning is-medium'><div class='column container is-two-thirds'><div class='column is-offset-one-third'><h2>".'No results found'."</h2></div></div></div>";
        ?>
      </section>
    </section> 
    
      <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.5/angular.min.js">
</script>
  </body>
</html>
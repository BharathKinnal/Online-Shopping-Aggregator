<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hello Bulma!</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.6.2/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
  </head>
  
  <body>
  <section class="hero is-primary">
    <div class="hero-body">
      <div class="container">
        <h1 class="title">
          ShopsMart
        </h1>
        <h2 class="subtitle">
          Search for products
        </h2>
      </div>
    </div>
  </section>
  
  <section class="sections">
    <div class="column container is-three-quarters is-centered">
      <form action="products.php" method="post">
        <div class="box">
          <div class="field">
            <div class=" level control has-icons-left">
              <span class="icon is-large is-left" style="margin-top:10px;margin-left:10px;">
                <i class="fas fa-2x fa-search"></i>
              </span>
              <input class=" input is-large is-info" type="text" placeholder="Search for a product across the web..." id='keyword' name='keyword'/>
              
            </div>
          </div>
        </div>
        <input class="button is-primary" type="submit" value="Submit"/>
      </form>
    </div>
  </section>

  <div class="columns is-multiline container" style="height:200px">
      <div class="column is-one-tenth">
      </div>
      <div class="column is-one-tenth">
      <p class="subtitle">
        <br>
        <br>

            Search from these websites :
        <br>
      </p>
    </div>
        <div class="column">
          <a href="https://www.flipkart.com">
            <figure class="image is-2by1">
              <img src="img/flipkart.png">
            </figure>
          </a>
        </div>

        <div class="column">
          <a href="https://www.amazon.in">
            <figure class="image is-2by1">
              <img src="img/amazon.png">
            </figure>
          </a>
        </div>
        
      </div>

  </body>
</html>